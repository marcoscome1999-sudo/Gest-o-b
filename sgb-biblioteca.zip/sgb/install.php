<?php // Executar uma vez e APAGAR este ficheiro.
$c=['localhost','biblioteca','root',''];  // igual a DB em inc.php
$p=new PDO("mysql:host=$c[0];charset=utf8mb4",$c[2],$c[3],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$p->exec("CREATE DATABASE IF NOT EXISTS `$c[1]` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");$p->exec("USE `$c[1]`");
$p->exec(file_get_contents(__DIR__.'/sql/schema.sql'));
if(!$p->query('SELECT COUNT(*) FROM utilizadores')->fetchColumn()){
 $p->prepare('INSERT INTO utilizadores(nome,email,senha,perfil) VALUES(?,?,?,?)')->execute(['Administrador','admin@biblioteca.local',password_hash('Admin@123',PASSWORD_DEFAULT),'admin']);
 echo 'Admin criado: admin@biblioteca.local / Admin@123 (altere a senha). ';}
echo 'Base de dados pronta. APAGUE install.php.';
