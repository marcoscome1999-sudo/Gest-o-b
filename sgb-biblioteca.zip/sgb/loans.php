<?php require 'inc.php';auth();chk();
if($_SERVER['REQUEST_METHOD']==='POST'){try{global $pdo;$pdo->beginTransaction();
 if($_POST['a']==='emprestar'){$l=(int)$_POST['livro'];$r=(int)$_POST['leitor'];
  $b=q('SELECT disponiveis FROM livros WHERE id=? AND activo=1 FOR UPDATE',[$l])->fetch();
  if(!$b||$b['disponiveis']<1)throw new Exception('Sem exemplares disponíveis. Faça uma reserva.');
  if(!q("SELECT 1 FROM leitores WHERE id=? AND estado='activo'",[$r])->fetch())throw new Exception('Leitor inactivo ou inexistente.');
  if(q("SELECT COUNT(*) FROM emprestimos WHERE leitor_id=? AND estado='emprestado'",[$r])->fetchColumn()>=MAX_EMP)throw new Exception('Limite de '.MAX_EMP.' empréstimos em simultâneo atingido.');
  $dp=$_POST['prevista']?:date('Y-m-d',strtotime('+'.DIAS_EMP.' days'));if($dp<date('Y-m-d'))throw new Exception('Data prevista inválida.');
  q('INSERT INTO emprestimos(livro_id,leitor_id,utilizador_id,data_emprestimo,data_prevista) VALUES(?,?,?,CURDATE(),?)',[$l,$r,$_SESSION['u']['id'],$dp]);
  q('UPDATE livros SET disponiveis=disponiveis-1 WHERE id=?',[$l]);
  q("UPDATE reservas SET estado='concluida' WHERE livro_id=? AND leitor_id=? AND estado IN('espera','notificada')",[$l,$r]);
  logx('emprestimo',"livro $l leitor $r");flash('Empréstimo registado.');}
 elseif($_POST['a']==='devolver'){$e=q("SELECT * FROM emprestimos WHERE id=? AND estado='emprestado' FOR UPDATE",[$_POST['id']])->fetch();if(!$e)throw new Exception('Empréstimo não encontrado.');
  $dias=max(0,(int)((strtotime(date('Y-m-d'))-strtotime($e['data_prevista']))/86400));
  q('INSERT INTO devolucoes(emprestimo_id,data_devolucao,utilizador_id) VALUES(?,CURDATE(),?)',[$e['id'],$_SESSION['u']['id']]);
  q("UPDATE emprestimos SET estado='devolvido' WHERE id=?",[$e['id']]);q('UPDATE livros SET disponiveis=disponiveis+1 WHERE id=?',[$e['livro_id']]);
  $m='Devolução registada.';if($dias>0){q('INSERT INTO multas(emprestimo_id,leitor_id,dias_atraso,valor) VALUES(?,?,?,?)',[$e['id'],$e['leitor_id'],$dias,$dias*MULTA_DIA]);$m.=" Multa: ".$dias*MULTA_DIA." MZN ($dias dias).";}
  $rs=q("SELECT r.id,l.email,b.titulo FROM reservas r JOIN leitores l ON l.id=r.leitor_id JOIN livros b ON b.id=r.livro_id WHERE r.livro_id=? AND r.estado='espera' ORDER BY r.id LIMIT 1",[$e['livro_id']])->fetch();
  if($rs){q("UPDATE reservas SET estado='notificada' WHERE id=?",[$rs['id']]);if($rs['email'])@mail($rs['email'],'Livro disponível','O livro "'.$rs['titulo'].'" que reservou já está disponível.');$m.=' Há um leitor em fila de espera (notificado).';}
  logx('devolucao',$e['id']);flash($m);}
 $pdo->commit();}catch(Throwable $x){if($pdo->inTransaction())$pdo->rollBack();flash('Erro: '.$x->getMessage());}
header('Location: loans.php');exit;}
head('Empréstimos e devoluções');?>
<form method="post" class="card card-body mb-4"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="a" value="emprestar"><div class="row g-2">
<div class="col-md-4"><select name="livro" class="form-select" required><option value="">Livro (disponíveis)…</option><?php foreach(q('SELECT id,titulo,disponiveis FROM livros WHERE activo=1 AND disponiveis>0 ORDER BY titulo')as$b)echo '<option value="'.$b['id'].'">'.e($b['titulo']).' ('.$b['disponiveis'].')</option>';?></select></div>
<div class="col-md-4"><select name="leitor" class="form-select" required><option value="">Leitor…</option><?php foreach(q("SELECT id,nome,bi FROM leitores WHERE estado='activo' ORDER BY nome")as$b)echo '<option value="'.$b['id'].'">'.e($b['nome'].' · '.$b['bi']).'</option>';?></select></div>
<div class="col-md-2"><input type="date" name="prevista" class="form-control" min="<?=date('Y-m-d')?>" title="Data prevista (padrão: <?=DIAS_EMP?> dias)"></div><div class="col-md-2"><button class="btn btn-primary w-100">Emprestar</button></div></div></form>
<?php $f=$_GET['f']??'activos';$w=['activos'=>"e.estado='emprestado'",'atraso'=>"e.estado='emprestado' AND e.data_prevista<CURDATE()",'todos'=>'1'][$f]??'1';
echo '<div class="mb-3">';foreach(['activos'=>'Activos','atraso'=>'Em atraso','todos'=>'Histórico']as$k=>$l)echo '<a class="btn btn-sm btn-'.($f===$k?'primary':'outline-primary').' me-1" href="?f='.$k.'">'.$l.'</a>';echo '</div>';
tbl(['Livro','Leitor','Emprestado','Prevista','Estado',''],array_map(fn($r)=>[$r['titulo'],$r['nome'],$r['data_emprestimo'],$r['data_prevista'],$r['estado']==='devolvido'?'Devolvido':($r['data_prevista']<date('Y-m-d')?['<span class="badge bg-danger">Atrasado</span>']:'Emprestado'),$r['estado']==='emprestado'?[btn('devolver',$r['id'],'Devolver','success')]:''],q("SELECT e.*,l.titulo,r.nome FROM emprestimos e JOIN livros l ON l.id=e.livro_id JOIN leitores r ON r.id=e.leitor_id WHERE $w ORDER BY e.id DESC LIMIT 200")->fetchAll()));foot();
