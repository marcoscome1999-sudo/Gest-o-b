<?php require 'inc.php';auth(true);chk();
if($_SERVER['REQUEST_METHOD']==='POST'){try{
 if($_POST['a']==='save'){$n=trim($_POST['nome']);$em=trim($_POST['email']);$s=$_POST['senha'];
  if($n===''||!filter_var($em,FILTER_VALIDATE_EMAIL)||strlen($s)<8)throw new Exception('Nome, email válido e senha (mín. 8 caracteres) são obrigatórios.');
  q('INSERT INTO utilizadores(nome,email,senha,perfil) VALUES(?,?,?,?)',[$n,$em,password_hash($s,PASSWORD_DEFAULT),$_POST['perfil']==='admin'?'admin':'bibliotecario']);logx('utilizador_criado',$em);flash('Utilizador criado.');}
 elseif($_POST['a']==='toggle'&&$_POST['id']!=$_SESSION['u']['id']){q('UPDATE utilizadores SET activo=1-activo WHERE id=?',[$_POST['id']]);logx('utilizador_estado',$_POST['id']);}
}catch(Throwable $x){flash('Erro: '.($x instanceof PDOException?'email já existente.':$x->getMessage()));}header('Location: users.php');exit;}
head('Utilizadores');?>
<form method="post" class="card card-body mb-4"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="a" value="save"><div class="row g-2"><div class="col-md-3"><input name="nome" class="form-control" placeholder="Nome" required></div><div class="col-md-3"><input name="email" type="email" class="form-control" placeholder="Email" required></div><div class="col-md-2"><input name="senha" type="password" minlength="8" class="form-control" placeholder="Senha" required></div><div class="col-md-2"><select name="perfil" class="form-select"><option value="bibliotecario">Bibliotecário</option><option value="admin">Administrador</option></select></div><div class="col-md-2"><button class="btn btn-primary w-100">Criar</button></div></div></form>
<?php tbl(['Nome','Email','Perfil','Estado',''],array_map(fn($u)=>[$u['nome'],$u['email'],$u['perfil'],$u['activo']?'Activo':'Inactivo',[btn('toggle',$u['id'],$u['activo']?'Desactivar':'Activar')]],q('SELECT * FROM utilizadores ORDER BY nome')->fetchAll()));
echo '<a class="btn btn-outline-dark mb-4" href="backup.php">💾 Descarregar cópia de segurança (SQL)</a><h5>Registo de actividades</h5>';
tbl(['Data','Utilizador','Acção','Detalhe'],q('SELECT a.criado_em,COALESCE(u.nome,"—"),a.accao,a.detalhe FROM actividades a LEFT JOIN utilizadores u ON u.id=a.utilizador_id ORDER BY a.id DESC LIMIT 100')->fetchAll(PDO::FETCH_NUM));foot();
