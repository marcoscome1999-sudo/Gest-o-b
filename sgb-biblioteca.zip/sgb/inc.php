<?php
session_start();
const DB=['localhost','biblioteca','root',''];   // <- ajustar (cPanel: utilizador/base criados no painel)
const MULTA_DIA=10; const DIAS_EMP=14; const MAX_EMP=3;
$pdo=new PDO('mysql:host='.DB[0].';dbname='.DB[1].';charset=utf8mb4',DB[2],DB[3],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function q($sql,$p=[]){global $pdo;$s=$pdo->prepare($sql);$s->execute($p);return $s;}
function csrf(){return $_SESSION['t']??=bin2hex(random_bytes(16));}
function chk(){if($_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals(csrf(),$_POST['t']??''))die('Pedido inválido (CSRF).');}
function auth($admin=false){if(empty($_SESSION['u'])){header('Location: login.php');exit;}if($admin&&$_SESSION['u']['perfil']!=='admin')die('Sem permissão.');}
function logx($a,$d=''){q('INSERT INTO actividades(utilizador_id,accao,detalhe) VALUES(?,?,?)',[$_SESSION['u']['id']??null,$a,$d]);}
function flash($m=null){if($m!==null){$_SESSION['f']=$m;return;}$x=$_SESSION['f']??'';unset($_SESSION['f']);return $x;}
function ref($t,$n){global $pdo;$n=trim($n);if($n==='')return null;$r=q("SELECT id FROM $t WHERE nome=?",[$n])->fetchColumn();if($r)return $r;q("INSERT INTO $t(nome) VALUES(?)",[$n]);return $pdo->lastInsertId();}
function btn($a,$id,$label,$cls='secondary',$conf=''){return '<form method="post" class="d-inline"'.($conf?' onsubmit="return confirm(\''.e($conf).'\')"':'').'><input type="hidden" name="t" value="'.csrf().'"><input type="hidden" name="a" value="'.e($a).'"><input type="hidden" name="id" value="'.(int)$id.'"><button class="btn btn-sm btn-outline-'.$cls.'">'.e($label).'</button></form>';}
function tbl($h,$rows){echo '<div class="table-responsive"><table class="table table-striped table-hover align-middle"><thead class="table-light"><tr>';foreach($h as $x)echo '<th>'.e($x).'</th>';echo '</tr></thead><tbody>';foreach($rows as $r){echo '<tr>';foreach($r as $c)echo '<td>'.(is_array($c)?$c[0]:e($c)).'</td>';echo '</tr>';}if(!$rows)echo '<tr><td colspan="'.count($h).'" class="text-muted">Sem registos.</td></tr>';echo '</tbody></table></div>';}
function head($title){
 $m=['index.php'=>'Dashboard','books.php'=>'Livros','readers.php'=>'Leitores','loans.php'=>'Empréstimos','reservations.php'=>'Reservas','reports.php'=>'Relatórios'];
 if($_SESSION['u']['perfil']==='admin')$m['users.php']='Utilizadores';
 $cur=basename($_SERVER['PHP_SELF']);
 echo '<!doctype html><html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).' · SGB</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:#f4f6f9}.side{background:#1e3a5f;min-height:100vh}.side a{color:#cfd8e6;padding:.6rem 1rem;display:block;text-decoration:none;border-radius:.4rem}.side a.on,.side a:hover{background:#2f5d9a;color:#fff}@media print{.side,.noprint{display:none!important}}</style></head><body><div class="container-fluid"><div class="row">';
 echo '<div class="col-md-2 side p-0"><div class="d-flex justify-content-between align-items-center p-3 text-white"><strong>📚 SGB</strong><button class="btn btn-sm btn-light d-md-none" data-bs-toggle="collapse" data-bs-target="#nav">☰</button></div><nav id="nav" class="collapse d-md-block px-2 pb-3">';
 foreach($m as $f=>$l)echo '<a href="'.$f.'" class="'.($f===$cur?'on':'').'">'.$l.'</a>';
 echo '<a href="logout.php" class="mt-3">Sair ('.e($_SESSION['u']['nome']).')</a></nav></div><main class="col-md-10 p-4"><form action="books.php" class="mb-3 noprint"><input name="q" class="form-control" placeholder="🔍 Pesquisar livros por título, autor, ISBN ou categoria"></form>';
 if($f=flash())echo '<div class="alert alert-info">'.e($f).'</div>';
 echo '<h3 class="mb-3">'.e($title).'</h3>';
}
function foot(){echo '</main></div></div><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>';}
