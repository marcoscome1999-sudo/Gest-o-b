<?php require 'inc.php';if(!empty($_SESSION['u']))logx('logout');session_destroy();header('Location: login.php');
