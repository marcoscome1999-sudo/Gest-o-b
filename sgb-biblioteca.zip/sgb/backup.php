<?php require 'inc.php';auth(true);logx('backup');
header('Content-Type: application/sql');header('Content-Disposition: attachment; filename=sgb_'.date('Ymd_His').'.sql');
echo "SET FOREIGN_KEY_CHECKS=0;\n";
foreach(q('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN)as$t){echo "DROP TABLE IF EXISTS `$t`;\n".q("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1].";\n";
 foreach(q("SELECT * FROM `$t`")as$r)echo "INSERT INTO `$t` VALUES(".implode(',',array_map(fn($v)=>$v===null?'NULL':$pdo->quote($v),$r)).");\n";}
echo "SET FOREIGN_KEY_CHECKS=1;\n";
