<?php require 'inc.php';auth();chk();
if($_SERVER['REQUEST_METHOD']==='POST'){try{
 if($_POST['a']==='save'){$n=trim($_POST['nome']);$bi=trim($_POST['bi']);$em=trim($_POST['email']);
  if($n===''||$bi==='')throw new Exception('Nome e nº de identificação são obrigatórios.');
  if($em!==''&&!filter_var($em,FILTER_VALIDATE_EMAIL))throw new Exception('Email inválido.');
  $p=[$n,$bi,trim($_POST['telefone']),$em,trim($_POST['endereco'])];
  if($_POST['id'])q('UPDATE leitores SET nome=?,bi=?,telefone=?,email=?,endereco=? WHERE id=?',[...$p,$_POST['id']]);
  else q('INSERT INTO leitores(nome,bi,telefone,email,endereco,data_inscricao) VALUES(?,?,?,?,?,CURDATE())',$p);
  logx('leitor_guardado',$n);flash('Leitor guardado.');}
 elseif($_POST['a']==='toggle'){q("UPDATE leitores SET estado=IF(estado='activo','inactivo','activo') WHERE id=?",[$_POST['id']]);logx('leitor_estado',$_POST['id']);}
 elseif($_POST['a']==='del'){auth(true);q('DELETE FROM leitores WHERE id=?',[$_POST['id']]);logx('leitor_eliminado',$_POST['id']);flash('Leitor eliminado.');}
}catch(Throwable $x){flash('Erro: '.($x instanceof PDOException?'identificação duplicada ou leitor com histórico (desactive-o).':$x->getMessage()));}
header('Location: readers.php');exit;}
$ed=!empty($_GET['edit'])?q('SELECT * FROM leitores WHERE id=?',[$_GET['edit']])->fetch():[];$v=fn($k)=>e($ed[$k]??'');head('Leitores');?>
<form method="post" class="card card-body mb-4"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="a" value="save"><input type="hidden" name="id" value="<?=$v('id')?>"><div class="row g-2">
<div class="col-md-4"><input name="nome" class="form-control" placeholder="Nome completo*" value="<?=$v('nome')?>" required></div><div class="col-md-3"><input name="bi" class="form-control" placeholder="Nº de identificação*" value="<?=$v('bi')?>" required></div><div class="col-md-2"><input name="telefone" class="form-control" placeholder="Telefone" value="<?=$v('telefone')?>"></div><div class="col-md-3"><input name="email" type="email" class="form-control" placeholder="Email" value="<?=$v('email')?>"></div>
<div class="col-md-9"><input name="endereco" class="form-control" placeholder="Endereço" value="<?=$v('endereco')?>"></div><div class="col-md-3"><button class="btn btn-primary w-100"><?=$ed?'Actualizar':'Registar'?></button></div></div></form>
<?php $s='%'.trim($_GET['f']??'').'%';?>
<form class="mb-3"><input name="f" class="form-control" placeholder="Filtrar leitores por nome, BI ou telefone" value="<?=e($_GET['f']??'')?>"></form>
<?php tbl(['Nome','Identificação','Telefone','Email','Inscrição','Estado',''],array_map(fn($r)=>[$r['nome'],$r['bi'],$r['telefone'],$r['email'],$r['data_inscricao'],ucfirst($r['estado']),['<a class="btn btn-sm btn-outline-primary" href="?edit='.$r['id'].'">Editar</a> '.btn('toggle',$r['id'],$r['estado']==='activo'?'Desactivar':'Activar').($_SESSION['u']['perfil']==='admin'?' '.btn('del',$r['id'],'Eliminar','danger','Eliminar este leitor?'):'')]],q('SELECT * FROM leitores WHERE nome LIKE ? OR bi LIKE ? OR telefone LIKE ? ORDER BY nome LIMIT 200',[$s,$s,$s])->fetchAll()));foot();
