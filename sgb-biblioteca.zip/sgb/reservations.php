<?php require 'inc.php';auth();chk();
if($_SERVER['REQUEST_METHOD']==='POST'){try{
 if($_POST['a']==='reservar'){$l=(int)$_POST['livro'];$r=(int)$_POST['leitor'];
  if(q('SELECT disponiveis FROM livros WHERE id=?',[$l])->fetchColumn()>0)throw new Exception('O livro está disponível: faça o empréstimo directamente.');
  if(q("SELECT 1 FROM reservas WHERE livro_id=? AND leitor_id=? AND estado IN('espera','notificada')",[$l,$r])->fetch())throw new Exception('Este leitor já tem reserva activa para o livro.');
  q('INSERT INTO reservas(livro_id,leitor_id) VALUES(?,?)',[$l,$r]);logx('reserva',"livro $l leitor $r");flash('Reserva registada.');}
 elseif($_POST['a']==='cancelar'){q("UPDATE reservas SET estado='cancelada' WHERE id=?",[$_POST['id']]);logx('reserva_cancelada',$_POST['id']);}
}catch(Throwable $x){flash('Erro: '.$x->getMessage());}header('Location: reservations.php');exit;}
head('Reservas');?>
<form method="post" class="card card-body mb-4"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="a" value="reservar"><div class="row g-2">
<div class="col-md-5"><select name="livro" class="form-select" required><option value="">Livro indisponível…</option><?php foreach(q('SELECT id,titulo FROM livros WHERE activo=1 AND disponiveis=0 ORDER BY titulo')as$b)echo '<option value="'.$b['id'].'">'.e($b['titulo']).'</option>';?></select></div>
<div class="col-md-5"><select name="leitor" class="form-select" required><option value="">Leitor…</option><?php foreach(q("SELECT id,nome FROM leitores WHERE estado='activo' ORDER BY nome")as$b)echo '<option value="'.$b['id'].'">'.e($b['nome']).'</option>';?></select></div><div class="col-md-2"><button class="btn btn-primary w-100">Reservar</button></div></div></form>
<?php tbl(['Livro','Leitor','Contacto','Data','Estado',''],array_map(fn($r)=>[$r['titulo'],$r['nome'],$r['telefone'].' '.$r['email'],$r['criada_em'],$r['estado']==='notificada'?['<span class="badge bg-success">Disponível — notificado</span>']:'Em espera',[btn('cancelar',$r['id'],'Cancelar','danger')]],q("SELECT r.*,b.titulo,l.nome,l.telefone,l.email FROM reservas r JOIN livros b ON b.id=r.livro_id JOIN leitores l ON l.id=r.leitor_id WHERE r.estado IN('espera','notificada') ORDER BY b.titulo,r.id")->fetchAll()));foot();
