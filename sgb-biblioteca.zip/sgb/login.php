<?php require 'inc.php';
if($_SERVER['REQUEST_METHOD']==='POST'){chk();
 if(($_SESSION['try']??0)>=5&&time()-($_SESSION['tt']??0)<300)$err='Demasiadas tentativas. Aguarde 5 minutos.';
 else{$u=q('SELECT * FROM utilizadores WHERE email=? AND activo=1',[trim($_POST['email'])])->fetch();
  if($u&&password_verify($_POST['senha'],$u['senha'])){session_regenerate_id(true);$_SESSION['u']=['id'=>$u['id'],'nome'=>$u['nome'],'perfil'=>$u['perfil']];$_SESSION['try']=0;logx('login');header('Location: index.php');exit;}
  $_SESSION['try']=($_SESSION['try']??0)+1;$_SESSION['tt']=time();$err='Credenciais inválidas.';}}
?><!doctype html><html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Entrar · SGB</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body style="background:#1e3a5f"><div class="container" style="max-width:400px;margin-top:12vh"><div class="card shadow"><div class="card-body p-4"><h4 class="text-center mb-4">📚 Sistema de Gestão de Biblioteca</h4>
<?php if(!empty($err))echo '<div class="alert alert-danger">'.e($err).'</div>';?>
<form method="post"><input type="hidden" name="t" value="<?=csrf()?>"><input name="email" type="email" class="form-control mb-3" placeholder="Email" required><input name="senha" type="password" class="form-control mb-3" placeholder="Senha" required><button class="btn btn-primary w-100">Entrar</button></form></div></div></div></body></html>
