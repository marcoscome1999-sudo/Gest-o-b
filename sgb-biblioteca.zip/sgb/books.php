<?php require 'inc.php';auth();chk();
if($_SERVER['REQUEST_METHOD']==='POST'){try{$a=$_POST['a'];
 if($a==='save'){$t=trim($_POST['titulo']);$isbn=trim($_POST['isbn']);$qt=(int)$_POST['quantidade'];
  if($t===''||$qt<1)throw new Exception('Título e quantidade (≥1) são obrigatórios.');
  $p=[$t,$isbn?:null,ref('autores',$_POST['autor']),ref('editoras',$_POST['editora']),ref('categorias',$_POST['categoria']),trim($_POST['localizacao'])];
  if($_POST['id']){$o=q('SELECT quantidade,disponiveis FROM livros WHERE id=?',[$_POST['id']])->fetch();$d=$o['disponiveis']+$qt-$o['quantidade'];
   if($d<0)throw new Exception('Quantidade inferior aos exemplares emprestados.');
   q('UPDATE livros SET titulo=?,isbn=?,autor_id=?,editora_id=?,categoria_id=?,localizacao=?,quantidade=?,disponiveis=? WHERE id=?',[...$p,$qt,$d,$_POST['id']]);}
  else q('INSERT INTO livros(titulo,isbn,autor_id,editora_id,categoria_id,localizacao,quantidade,disponiveis) VALUES(?,?,?,?,?,?,?,?)',[...$p,$qt,$qt]);
  logx('livro_guardado',$t);flash('Livro guardado.');}
 elseif($a==='toggle'){q('UPDATE livros SET activo=1-activo WHERE id=?',[$_POST['id']]);logx('livro_estado',$_POST['id']);}
 elseif($a==='del'){auth(true);q('DELETE FROM livros WHERE id=?',[$_POST['id']]);logx('livro_eliminado',$_POST['id']);flash('Livro eliminado.');}
}catch(Throwable $x){flash('Erro: '.($x instanceof PDOException?'registo duplicado ou em uso (ISBN / empréstimos associados).':$x->getMessage()));}
header('Location: books.php');exit;}
$ed=!empty($_GET['edit'])?q('SELECT l.*,a.nome autor,e.nome editora,c.nome categoria FROM livros l LEFT JOIN autores a ON a.id=l.autor_id LEFT JOIN editoras e ON e.id=l.editora_id LEFT JOIN categorias c ON c.id=l.categoria_id WHERE l.id=?',[$_GET['edit']])->fetch():[];
$v=fn($k)=>e($ed[$k]??'');head('Livros');?>
<form method="post" class="card card-body mb-4"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="a" value="save"><input type="hidden" name="id" value="<?=$v('id')?>">
<div class="row g-2"><div class="col-md-5"><input name="titulo" class="form-control" placeholder="Título*" value="<?=$v('titulo')?>" required></div><div class="col-md-3"><input name="isbn" class="form-control" placeholder="ISBN" value="<?=$v('isbn')?>"></div><div class="col-md-4"><input name="autor" class="form-control" placeholder="Autor" value="<?=$v('autor')?>"></div>
<div class="col-md-3"><input name="editora" class="form-control" placeholder="Editora" value="<?=$v('editora')?>"></div><div class="col-md-3"><input name="categoria" class="form-control" placeholder="Categoria" value="<?=$v('categoria')?>"></div><div class="col-md-2"><input name="quantidade" type="number" min="1" class="form-control" placeholder="Qtd*" value="<?=$v('quantidade')?:1?>" required></div><div class="col-md-2"><input name="localizacao" class="form-control" placeholder="Localização (ex: A3-P2)" value="<?=$v('localizacao')?>"></div><div class="col-md-2"><button class="btn btn-primary w-100"><?=$ed?'Actualizar':'Adicionar'?></button></div></div></form>
<?php $s='%'.trim($_GET['q']??'').'%';
$rows=q('SELECT l.*,a.nome autor,c.nome categoria FROM livros l LEFT JOIN autores a ON a.id=l.autor_id LEFT JOIN categorias c ON c.id=l.categoria_id WHERE l.titulo LIKE ? OR l.isbn LIKE ? OR a.nome LIKE ? OR c.nome LIKE ? ORDER BY l.titulo LIMIT 200',[$s,$s,$s,$s])->fetchAll();
tbl(['Título','Autor','Categoria','ISBN','Local','Disp./Total','Estado',''],array_map(fn($r)=>[$r['titulo'],$r['autor'],$r['categoria'],$r['isbn'],$r['localizacao'],$r['disponiveis'].'/'.$r['quantidade'],$r['activo']?'Activo':'Inactivo',['<a class="btn btn-sm btn-outline-primary" href="?edit='.$r['id'].'">Editar</a> '.btn('toggle',$r['id'],$r['activo']?'Desactivar':'Activar').($_SESSION['u']['perfil']==='admin'?' '.btn('del',$r['id'],'Eliminar','danger','Eliminar este livro?'):'')]],$rows));foot();
