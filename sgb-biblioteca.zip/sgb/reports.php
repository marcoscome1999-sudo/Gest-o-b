<?php require 'inc.php';auth();chk();
if($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['a']??'')==='paga'){q('UPDATE multas SET paga=1 WHERE id=?',[$_POST['id']]);logx('multa_paga',$_POST['id']);header('Location: reports.php?r=multas');exit;}
$N=PDO::FETCH_NUM;
$R=['disponiveis'=>['Livros disponíveis',['Título','ISBN','Disponíveis','Total','Local'],"SELECT titulo,isbn,disponiveis,quantidade,localizacao FROM livros WHERE activo=1 AND disponiveis>0 ORDER BY titulo"],
'emprestados'=>['Livros emprestados',['Livro','Leitor','Emprestado','Prevista'],"SELECT l.titulo,r.nome,e.data_emprestimo,e.data_prevista FROM emprestimos e JOIN livros l ON l.id=e.livro_id JOIN leitores r ON r.id=e.leitor_id WHERE e.estado='emprestado' ORDER BY e.data_prevista"],
'atrasos'=>['Atrasos',['Livro','Leitor','Telefone','Prevista','Dias de atraso'],"SELECT l.titulo,r.nome,r.telefone,e.data_prevista,DATEDIFF(CURDATE(),e.data_prevista) FROM emprestimos e JOIN livros l ON l.id=e.livro_id JOIN leitores r ON r.id=e.leitor_id WHERE e.estado='emprestado' AND e.data_prevista<CURDATE() ORDER BY e.data_prevista"],
'leitores'=>['Leitores activos',['Nome','Identificação','Telefone','Email','Empréstimos'],"SELECT r.nome,r.bi,r.telefone,r.email,(SELECT COUNT(*) FROM emprestimos e WHERE e.leitor_id=r.id) FROM leitores r WHERE r.estado='activo' ORDER BY r.nome"],
'multas'=>['Multas',['Leitor','Dias','Valor (MZN)','Estado','Id'],"SELECT r.nome,m.dias_atraso,m.valor,IF(m.paga,'Paga','Por pagar'),m.id FROM multas m JOIN leitores r ON r.id=m.leitor_id ORDER BY m.paga,m.id DESC"],
'mensal'=>['Estatísticas mensais',['Mês','Empréstimos','Multas (MZN)'],"SELECT DATE_FORMAT(e.data_emprestimo,'%Y-%m') p,COUNT(*),COALESCE(SUM(m.valor),0) FROM emprestimos e LEFT JOIN multas m ON m.emprestimo_id=e.id GROUP BY p ORDER BY p DESC"],
'anual'=>['Estatísticas anuais',['Ano','Empréstimos','Multas (MZN)'],"SELECT YEAR(e.data_emprestimo) p,COUNT(*),COALESCE(SUM(m.valor),0) FROM emprestimos e LEFT JOIN multas m ON m.emprestimo_id=e.id GROUP BY p ORDER BY p DESC"]];
$k=$_GET['r']??'disponiveis';if(!isset($R[$k]))$k='disponiveis';[$tt,$h,$sql]=$R[$k];$rows=q($sql)->fetchAll($N);
if(isset($_GET['csv'])){logx('exportacao',$k);header('Content-Type: text/csv; charset=utf-8');header("Content-Disposition: attachment; filename=$k.csv");echo "\xEF\xBB\xBF";$o=fopen('php://output','w');if($k==='multas'){array_pop($h);$rows=array_map(fn($r)=>array_slice($r,0,4),$rows);}fputcsv($o,$h,';');foreach($rows as $r)fputcsv($o,$r,';');exit;}
head($tt);echo '<div class="noprint mb-3">';foreach($R as $x=>$d)echo '<a class="btn btn-sm btn-'.($x===$k?'primary':'outline-primary').' me-1 mb-1" href="?r='.$x.'">'.e($d[0]).'</a>';
echo '</div><div class="noprint mb-3"><a class="btn btn-success btn-sm" href="?r='.$k.'&csv=1">⬇ Excel (CSV)</a> <button class="btn btn-danger btn-sm" onclick="print()">⬇ PDF (Imprimir → Guardar como PDF)</button></div>';
if($k==='multas'){array_pop($h);$h[]='';$rows=array_map(fn($r)=>[$r[0],$r[1],$r[2],$r[3],$r[3]==='Por pagar'?[btn('paga',$r[4],'Marcar paga','success')]:''],$rows);}
tbl($h,$rows);foot();
